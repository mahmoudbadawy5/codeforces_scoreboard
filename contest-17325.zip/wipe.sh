echo [INFO]: Wiping problem 'exams'.
cd problems/exams
./wipe.sh
cd -

echo [INFO]: Wiping problem 'andorxor'.
cd problems/andorxor
./wipe.sh
cd -

echo [INFO]: Wiping problem 'naruto-and-ichiraku-san'.
cd problems/naruto-and-ichiraku-san
./wipe.sh
cd -

echo [INFO]: Wiping problem 'keys-and-lamps-codeforces'.
cd problems/keys-and-lamps-codeforces
./wipe.sh
cd -

echo [INFO]: Wiping english contest statement.
cd statements/english
./wipe.sh
cd -


#!/usr/bin/env bash
echo "Running 0 validator test(s)"
echo "Running 0 validator test(s)" 1> validator-tests.log
rm -f validator-tests.log
echo "Validator test(s) finished"

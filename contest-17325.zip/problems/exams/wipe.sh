#!/usr/bin/env bash
#   *** samples ***
rm -f samples/01.a

#   *** tests ***
rm -f tests/01
rm -f tests/01.a
rm -f tests/02
rm -f tests/02.a
rm -f tests/03
rm -f tests/03.a
rm -f tests/04
rm -f tests/04.a


#!/usr/bin/env bash
#   *** samples ***
rm -f samples/01.a

#   *** tests ***
rm -f tests/01
rm -f tests/01.a


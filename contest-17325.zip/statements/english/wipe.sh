cd ../../problems/exams/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/andorxor/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/naruto-and-ichiraku-san/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

cd ../../problems/keys-and-lamps-codeforces/statements/english
rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
cd -

rm -f *.log
rm -f *.aux
rm -f *.dvi
rm -f *.pdf
rm -f *.ps
